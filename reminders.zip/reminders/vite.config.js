import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base: "./" keeps asset paths relative so it works on GitHub Pages
// project sites (username.github.io/repo/) without hard-coding the repo name.
export default defineConfig({
  base: "./",
  plugins: [react()],
});
