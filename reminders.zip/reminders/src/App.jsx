import { useState, useEffect, useRef } from "react";
import {
  Check, Plus, ChevronRight, List, ChevronLeft,
  Timer, Play, Pause, RotateCcw, SkipForward, X,
} from "lucide-react";

// ---- iOS design language -------------------------------------------
const iOS = {
  groupedBg: "#F2F2F7",
  card: "#FFFFFF",
  label: "#000000",
  secondary: "rgba(60,60,67,0.60)",
  tertiary: "rgba(60,60,67,0.30)",
  separator: "#C6C6C8",
  blue: "#007AFF",
  red: "#FF3B30",
};
const FONT =
  '-apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Helvetica Neue", Helvetica, Arial, sans-serif';

const LIST_COLORS = [
  "#FF3B30", "#FF9500", "#FFCC00", "#34C759",
  "#30B0C7", "#007AFF", "#5856D6", "#AF52DE",
];
const FILTERS = [
  { id: "all", label: "すべて" },
  { id: "active", label: "未完了" },
  { id: "done", label: "完了" },
];
const STORE_KEY = "reminders:v2";
const uid = () => Date.now() + Math.random();

// pomodoro durations (seconds)
const FOCUS = 25 * 60;
const BREAK = 5 * 60;
const LONG = 15 * 60;
const REST = "#2DD4A7"; // calm mint for breaks

const SEED_LISTS = [
  { id: "l1", name: "個人", color: "#007AFF" },
  { id: "l2", name: "仕事", color: "#FF9500" },
  { id: "l3", name: "買い物", color: "#34C759" },
];
const SEED_TODOS = [
  { id: uid(), listId: "l1", text: "ジムに行く", done: false },
  { id: uid(), listId: "l1", text: "図書館に本を返す", done: true },
  { id: uid(), listId: "l2", text: "企画書を送る", done: false },
  { id: uid(), listId: "l3", text: "牛乳", done: false },
  { id: uid(), listId: "l3", text: "卵", done: false },
];

const fmt = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

// ---- swipe-to-delete hook ------------------------------------------
function useSwipe({ isOpen, onOpen, onClose, reveal = 84 }) {
  const [dx, setDx] = useState(0);
  const drag = useRef({ active: false, startX: 0, moved: false, base: 0 });
  useEffect(() => {
    if (!isOpen && !drag.current.active) setDx(0);
  }, [isOpen]);
  const onPointerDown = (e) => {
    e.currentTarget.setPointerCapture?.(e.pointerId);
    drag.current = { active: true, startX: e.clientX, moved: false, base: isOpen ? -reveal : 0 };
  };
  const onPointerMove = (e) => {
    if (!drag.current.active) return;
    const d = e.clientX - drag.current.startX;
    if (Math.abs(d) > 4) drag.current.moved = true;
    let n = drag.current.base + d;
    n = Math.max(-reveal - 24, Math.min(0, n));
    setDx(n);
  };
  const end = () => {
    if (!drag.current.active) return;
    drag.current.active = false;
    setDx((cur) => {
      if (cur < -reveal / 2) { onOpen(); return -reveal; }
      onClose(); return 0;
    });
  };
  return {
    dx,
    moved: () => drag.current.moved,
    dragging: () => drag.current.active,
    handlers: { onPointerDown, onPointerMove, onPointerUp: end, onPointerCancel: end },
  };
}

export default function App() {
  const [lists, setLists] = useState([]);
  const [todos, setTodos] = useState([]);
  const [view, setView] = useState("home");
  const [activeId, setActiveId] = useState(null);
  const [focusId, setFocusId] = useState(null); // list being focused
  const [loaded, setLoaded] = useState(false);

  // load once from localStorage (falls back to seed data on first run)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const d = JSON.parse(raw);
        setLists(d.lists || SEED_LISTS);
        setTodos(d.todos || []);
      } else {
        setLists(SEED_LISTS);
        setTodos(SEED_TODOS);
      }
    } catch (e) {
      setLists(SEED_LISTS);
      setTodos(SEED_TODOS);
    } finally {
      setLoaded(true);
    }
  }, []);

  // persist to localStorage on every change
  useEffect(() => {
    if (!loaded) return;
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ lists, todos }));
    } catch (e) {
      console.error("保存に失敗しました", e);
    }
  }, [lists, todos, loaded]);

  const openList = (id) => { setActiveId(id); setView("detail"); };
  const activeList = lists.find((l) => l.id === activeId) || null;
  const focusList = lists.find((l) => l.id === focusId) || null;

  return (
    <div
      style={{ background: iOS.groupedBg, color: iOS.label, fontFamily: FONT }}
      className="w-full flex justify-center h-screen overflow-hidden"
    >
      <div className="w-full max-w-md h-full overflow-hidden relative">
        <div
          className="flex h-full"
          style={{
            width: "200%",
            transform: view === "home" ? "translateX(0)" : "translateX(-50%)",
            transition: "transform 360ms cubic-bezier(.36,.66,.04,1)",
          }}
        >
          <div style={{ width: "50%" }} className="h-full">
            <HomeScreen lists={lists} todos={todos} setLists={setLists} setTodos={setTodos} onOpen={openList} />
          </div>
          <div style={{ width: "50%" }} className="h-full">
            {activeList && (
              <DetailScreen
                list={activeList}
                todos={todos}
                setTodos={setTodos}
                onBack={() => setView("home")}
                onStartFocus={() => setFocusId(activeList.id)}
              />
            )}
          </div>
        </div>

        {focusList && (
          <FocusMode
            list={focusList}
            todos={todos}
            setTodos={setTodos}
            onClose={() => setFocusId(null)}
          />
        )}
      </div>
    </div>
  );
}

// ---- home: all lists -----------------------------------------------
function HomeScreen({ lists, todos, setLists, setTodos, onOpen }) {
  const [openId, setOpenId] = useState(null);
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [color, setColor] = useState(LIST_COLORS[5]);
  const [confirm, setConfirm] = useState(null);

  const countFor = (id) => todos.filter((t) => t.listId === id && !t.done).length;

  const addList = () => {
    const n = name.trim();
    if (!n) return;
    setLists((p) => [...p, { id: uid(), name: n, color }]);
    setName(""); setColor(LIST_COLORS[5]); setAdding(false);
  };
  const doDelete = (list) => {
    if (todos.some((t) => t.listId === list.id)) { setConfirm(list); return; }
    removeList(list.id);
  };
  const removeList = (id) => {
    setLists((p) => p.filter((l) => l.id !== id));
    setTodos((p) => p.filter((t) => t.listId !== id));
    setOpenId(null); setConfirm(null);
  };

  return (
    <div className="h-full flex flex-col" onClick={() => setOpenId(null)}>
      <div className="px-5 pt-14 pb-4 shrink-0">
        <h1 style={{ fontSize: 34, fontWeight: 700, letterSpacing: "0.011em" }}>リスト</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-10">
        <div className="rounded-[10px] overflow-hidden" style={{ background: iOS.card }}>
          {lists.map((l, i) => (
            <ListRow
              key={l.id} list={l} first={i === 0} count={countFor(l.id)}
              isOpen={openId === l.id}
              onOpen={() => setOpenId(l.id)} onClose={() => setOpenId(null)}
              onTap={() => onOpen(l.id)} onDelete={() => doDelete(l)}
            />
          ))}
          {lists.length === 0 && (
            <div className="py-14 text-center" style={{ color: iOS.secondary, fontSize: 15 }}>リストがありません</div>
          )}
        </div>

        <div className="mt-4" onClick={(e) => e.stopPropagation()}>
          {!adding ? (
            <button
              onClick={() => setAdding(true)}
              className="flex items-center gap-2 px-1 py-2 active:opacity-60 transition"
              style={{ color: iOS.blue, fontSize: 17, fontWeight: 600 }}
            >
              <span className="h-6 w-6 grid place-items-center rounded-full" style={{ background: iOS.blue, color: "#fff" }}>
                <Plus size={16} strokeWidth={3} />
              </span>
              リストを追加
            </button>
          ) : (
            <div className="rounded-[10px] p-4" style={{ background: iOS.card }}>
              <input
                autoFocus value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addList()}
                placeholder="リスト名"
                className="w-full bg-transparent outline-none mb-4"
                style={{ fontSize: 17, textAlign: "center", fontWeight: 600 }}
              />
              <div className="flex justify-center gap-3 mb-5">
                {LIST_COLORS.map((c) => (
                  <button
                    key={c} onClick={() => setColor(c)}
                    className="rounded-full transition active:scale-90"
                    style={{ height: 28, width: 28, background: c, boxShadow: color === c ? `0 0 0 2px #fff, 0 0 0 4px ${c}` : "none" }}
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={() => { setAdding(false); setName(""); }} className="flex-1 py-2.5 rounded-[10px] font-semibold" style={{ background: iOS.groupedBg, color: iOS.label, fontSize: 16 }}>キャンセル</button>
                <button onClick={addList} disabled={!name.trim()} className="flex-1 py-2.5 rounded-[10px] font-semibold transition" style={{ background: name.trim() ? iOS.blue : "rgba(0,122,255,0.35)", color: "#fff", fontSize: 16 }}>追加</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {confirm && (
        <Alert
          title={`「${confirm.name}」を削除`}
          message="このリストと、含まれるすべての項目が削除されます。"
          onCancel={() => setConfirm(null)}
          onConfirm={() => removeList(confirm.id)}
        />
      )}
    </div>
  );
}

function ListRow({ list, first, count, isOpen, onOpen, onClose, onTap, onDelete }) {
  const REVEAL = 84;
  const sw = useSwipe({ isOpen, onOpen, onClose, reveal: REVEAL });
  const click = (e) => {
    e.stopPropagation();
    if (sw.moved()) return;
    if (isOpen) { onClose(); return; }
    onTap();
  };
  return (
    <div className="relative overflow-hidden" style={{ background: iOS.red }}>
      <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className="absolute top-0 right-0 h-full flex items-center justify-center" style={{ width: REVEAL, color: "#fff", fontSize: 15, fontWeight: 500 }}>削除</button>
      <div
        onClick={click} {...sw.handlers}
        className="relative flex items-center gap-3 pl-4 pr-3"
        style={{ background: iOS.card, transform: `translateX(${sw.dx}px)`, transition: sw.dragging() ? "none" : "transform 320ms cubic-bezier(.36,.66,.04,1)", touchAction: "pan-y" }}
      >
        <span className="shrink-0 grid place-items-center rounded-full" style={{ height: 30, width: 30, background: list.color, color: "#fff" }}>
          <List size={16} strokeWidth={2.6} />
        </span>
        <div className="flex-1 flex items-center justify-between py-3.5" style={{ borderTop: first ? "none" : `0.5px solid ${iOS.separator}` }}>
          <span style={{ fontSize: 17 }}>{list.name}</span>
          <span className="flex items-center gap-1.5 tabular-nums" style={{ color: iOS.secondary }}>
            {count > 0 && <span style={{ fontSize: 17 }}>{count}</span>}
            <ChevronRight size={18} color={iOS.tertiary} />
          </span>
        </div>
      </div>
    </div>
  );
}

// ---- detail: one list ----------------------------------------------
function DetailScreen({ list, todos, setTodos, onBack, onStartFocus }) {
  const [text, setText] = useState("");
  const [filter, setFilter] = useState("all");
  const [openId, setOpenId] = useState(null);
  const inputRef = useRef(null);
  const accent = list.color;

  const mine = todos.filter((t) => t.listId === list.id);
  const shown = mine.filter((t) => (filter === "active" ? !t.done : filter === "done" ? t.done : true));
  const remaining = mine.filter((t) => !t.done).length;
  const segIndex = FILTERS.findIndex((f) => f.id === filter);

  const add = () => {
    const t = text.trim();
    if (!t) return;
    setTodos((p) => [...p, { id: uid(), listId: list.id, text: t, done: false }]);
    setText(""); inputRef.current?.focus();
  };
  const toggle = (id) => setTodos((p) => p.map((t) => (t.id === id ? { ...t, done: !t.done } : t)));
  const remove = (id) => { setTodos((p) => p.filter((t) => t.id !== id)); setOpenId(null); };

  return (
    <div className="h-full flex flex-col" onClick={() => setOpenId(null)}>
      <div className="px-4 pt-12 pb-2 shrink-0">
        <button onClick={(e) => { e.stopPropagation(); onBack(); }} className="flex items-center active:opacity-60 transition -ml-1 mb-2" style={{ color: accent, fontSize: 17 }}>
          <ChevronLeft size={26} strokeWidth={2.4} />リスト
        </button>
        <div className="flex items-end justify-between px-1">
          <h1 style={{ fontSize: 34, fontWeight: 700, letterSpacing: "0.011em", color: accent }}>{list.name}</h1>
          <span style={{ color: iOS.secondary, fontSize: 15 }} className="pb-1 tabular-nums">{remaining} 件</span>
        </div>
      </div>

      <div className="px-4 pt-3 pb-2 shrink-0">
        <div className="relative flex p-0.5 rounded-[9px] select-none" style={{ background: "rgba(118,118,128,0.12)" }}>
          <div className="absolute top-0.5 bottom-0.5 rounded-[7px]" style={{ width: "calc((100% - 4px) / 3)", left: 2, transform: `translateX(${segIndex * 100}%)`, background: "#fff", boxShadow: "0 3px 8px rgba(0,0,0,0.12), 0 1px 1px rgba(0,0,0,0.04)", transition: "transform 260ms cubic-bezier(.36,.66,.04,1)" }} />
          {FILTERS.map((f) => (
            <button key={f.id} onClick={() => setFilter(f.id)} className="relative z-10 flex-1 py-1.5 text-[13px] font-semibold" style={{ color: filter === f.id ? iOS.label : iOS.secondary }}>{f.label}</button>
          ))}
        </div>
      </div>

      {/* focus mode entry */}
      {remaining > 0 && (
        <div className="px-4 pt-1 pb-2 shrink-0">
          <button
            onClick={(e) => { e.stopPropagation(); onStartFocus(); }}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-[12px] font-semibold active:scale-[0.98] transition"
            style={{ background: `${accent}1F`, color: accent, fontSize: 16 }}
          >
            <Timer size={18} strokeWidth={2.4} />集中モードを始める
          </button>
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-4 pb-4">
        {shown.length === 0 ? (
          <div className="text-center rounded-[10px] py-16" style={{ background: iOS.card, color: iOS.secondary, fontSize: 15 }}>
            {filter === "done" ? "完了した項目はありません" : filter === "active" ? "未完了の項目はありません" : "下のバーから項目を追加できます"}
          </div>
        ) : (
          <div className="rounded-[10px] overflow-hidden" style={{ background: iOS.card }}>
            {shown.map((td, i) => (
              <TodoRow key={td.id} todo={td} first={i === 0} accent={accent}
                isOpen={openId === td.id}
                onOpen={() => setOpenId(td.id)} onClose={() => setOpenId(null)}
                onToggle={() => toggle(td.id)} onRemove={() => remove(td.id)} />
            ))}
          </div>
        )}
      </div>

      <div
        className="px-4 pt-3 pb-8 shrink-0"
        style={{ background: "rgba(242,242,247,0.80)", backdropFilter: "saturate(180%) blur(20px)", WebkitBackdropFilter: "saturate(180%) blur(20px)", borderTop: `0.5px solid ${iOS.separator}` }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2 rounded-[12px] px-3.5 py-2.5" style={{ background: iOS.card, border: `0.5px solid ${iOS.separator}` }}>
            <div className="h-[22px] w-[22px] rounded-full shrink-0" style={{ border: `1.6px solid ${iOS.tertiary}` }} />
            <input ref={inputRef} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} placeholder="新しいリマインダー" className="flex-1 bg-transparent outline-none" style={{ fontSize: 17, color: iOS.label }} />
          </div>
          <button onClick={add} aria-label="追加" disabled={!text.trim()} className="h-11 w-11 grid place-items-center rounded-full transition active:scale-90" style={{ background: text.trim() ? accent : "rgba(0,0,0,0.20)", color: "#fff" }}>
            <Plus size={22} strokeWidth={2.6} />
          </button>
        </div>
      </div>
    </div>
  );
}

function TodoRow({ todo, first, accent, isOpen, onOpen, onClose, onToggle, onRemove }) {
  const REVEAL = 84;
  const sw = useSwipe({ isOpen, onOpen, onClose, reveal: REVEAL });
  const rowClick = (e) => { e.stopPropagation(); if (sw.moved()) return; if (isOpen) onClose(); };
  return (
    <div className="relative overflow-hidden" style={{ background: iOS.red }}>
      <button onClick={(e) => { e.stopPropagation(); onRemove(); }} className="absolute top-0 right-0 h-full flex items-center justify-center" style={{ width: REVEAL, color: "#fff", fontSize: 15, fontWeight: 500 }}>削除</button>
      <div onClick={rowClick} {...sw.handlers} className="relative flex items-start gap-3 pr-4"
        style={{ background: iOS.card, paddingLeft: 16, transform: `translateX(${sw.dx}px)`, transition: sw.dragging() ? "none" : "transform 320ms cubic-bezier(.36,.66,.04,1)", touchAction: "pan-y" }}>
        <button onClick={(e) => { e.stopPropagation(); if (sw.moved()) return; onToggle(); }} aria-label={todo.done ? "未完了に戻す" : "完了にする"} className="shrink-0 grid place-items-center rounded-full active:scale-90 transition"
          style={{ height: 22, width: 22, marginTop: 12, background: todo.done ? accent : "transparent", border: `1.6px solid ${todo.done ? accent : iOS.tertiary}` }}>
          {todo.done && <Check size={13} strokeWidth={3.4} color="#fff" />}
        </button>
        <div className="flex-1 py-3" style={{ borderTop: first ? "none" : `0.5px solid ${iOS.separator}` }}>
          <span style={{ fontSize: 17, lineHeight: 1.3, color: todo.done ? iOS.secondary : iOS.label, textDecoration: todo.done ? "line-through" : "none", textDecorationColor: iOS.tertiary }}>{todo.text}</span>
        </div>
      </div>
    </div>
  );
}

// ---- focus mode (pomodoro) -----------------------------------------
function FocusMode({ list, todos, setTodos, onClose }) {
  const accent = list.color;
  const [mode, setMode] = useState("focus"); // focus | break | long
  const [running, setRunning] = useState(false);
  const [left, setLeft] = useState(FOCUS);
  const [done, setDone] = useState(0); // completed focus sessions
  const [currentId, setCurrentId] = useState(null);

  const listIncomplete = todos.filter((t) => t.listId === list.id && !t.done);

  // pick an initial / next task
  useEffect(() => {
    const stillValid = todos.find((t) => t.id === currentId && !t.done);
    if (!stillValid) {
      const first = todos.find((t) => t.listId === list.id && !t.done);
      setCurrentId(first ? first.id : null);
    }
  }, [todos]); // eslint-disable-line

  // ticking
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(id);
  }, [running]);

  // segment transition when time runs out
  useEffect(() => {
    if (left !== 0) return;
    if (mode === "focus") {
      const n = done + 1;
      setDone(n);
      if (n % 4 === 0) { setMode("long"); setLeft(LONG); }
      else { setMode("break"); setLeft(BREAK); }
    } else {
      setMode("focus"); setLeft(FOCUS);
    }
  }, [left]); // eslint-disable-line

  const total = mode === "focus" ? FOCUS : mode === "long" ? LONG : BREAK;
  const isBreak = mode !== "focus";
  const ring = isBreak ? REST : accent;

  const R = 130, C = 2 * Math.PI * R;
  const frac = left / total;
  const offset = C * (1 - frac);

  const resetSeg = () => setLeft(total);
  const skipSeg = () => setLeft(0);

  const completeTask = () => {
    if (!currentId) return;
    const rest = listIncomplete.filter((t) => t.id !== currentId);
    setTodos((p) => p.map((t) => (t.id === currentId ? { ...t, done: true } : t)));
    setCurrentId(rest[0] ? rest[0].id : null);
  };
  const skipTask = () => {
    if (listIncomplete.length < 2) return;
    const i = listIncomplete.findIndex((t) => t.id === currentId);
    const next = listIncomplete[(i + 1) % listIncomplete.length];
    setCurrentId(next.id);
  };

  const currentTask = todos.find((t) => t.id === currentId) || null;
  const nextTask = listIncomplete.find((t) => t.id !== currentId) || null;

  return (
    <div
      className="absolute inset-0 z-50 flex flex-col"
      style={{
        background: `radial-gradient(120% 80% at 50% 18%, ${ring}26 0%, #0B0B0F 55%), #0B0B0F`,
        color: "#fff",
        transition: "background 600ms ease",
      }}
    >
      {/* top bar */}
      <div className="flex items-center justify-between px-5 pt-14 pb-2 shrink-0">
        <button onClick={onClose} aria-label="閉じる" className="h-9 w-9 grid place-items-center rounded-full active:scale-90 transition" style={{ background: "rgba(255,255,255,0.10)" }}>
          <X size={20} />
        </button>
        <div className="flex items-center gap-1.5">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className="rounded-full transition-all" style={{ height: 6, width: 6, background: i < done % 4 ? ring : "rgba(255,255,255,0.22)" }} />
          ))}
        </div>
      </div>

      {/* current task — the hero of focus mode */}
      <div className="px-7 pt-5 pb-1 shrink-0 text-center flex flex-col justify-center" style={{ minHeight: 132 }}>
        {isBreak ? (
          <>
            <div style={{ fontSize: 13, letterSpacing: "0.14em", color: "rgba(255,255,255,0.55)" }}>BREAK</div>
            <div className="mt-1" style={{ fontSize: 24, fontWeight: 600 }}>ひと休みしよう</div>
          </>
        ) : currentTask ? (
          <button onClick={skipTask} className="w-full active:opacity-70 transition">
            <div style={{ fontSize: 12, letterSpacing: "0.14em", color: "rgba(255,255,255,0.4)" }}>いま集中すること</div>
            <div className="mt-2 mx-auto" style={{ fontSize: 36, fontWeight: 700, lineHeight: 1.22, letterSpacing: "0.01em", maxWidth: 330, display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
              {currentTask.text}
            </div>
          </button>
        ) : (
          <div style={{ fontSize: 26, fontWeight: 700 }}>このリストは完了 🎉</div>
        )}
      </div>

      {/* timer ring — smaller, so the task stays the focus */}
      <div className="flex-1 flex items-center justify-center">
        <div className="relative" style={{ width: 208, height: 208 }}>
          <svg width="208" height="208" viewBox="0 0 300 300" style={{ transform: "rotate(-90deg)" }}>
            <circle cx="150" cy="150" r={R} fill="none" stroke="rgba(255,255,255,0.10)" strokeWidth="12" />
            <circle
              cx="150" cy="150" r={R} fill="none" stroke={ring} strokeWidth="12" strokeLinecap="round"
              strokeDasharray={C} strokeDashoffset={offset}
              style={{ transition: "stroke-dashoffset 0.95s linear, stroke 500ms ease" }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div style={{ fontSize: 32, fontWeight: 300, letterSpacing: "0.01em", fontVariantNumeric: "tabular-nums" }}>{fmt(left)}</div>
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", marginTop: 1 }}>
              {mode === "focus" ? "集中" : mode === "long" ? "ロング休憩" : "休憩"}
            </div>
          </div>
        </div>
      </div>

      {/* controls */}
      <div className="shrink-0 px-8 pb-2">
        <div className="flex items-center justify-center gap-8">
          <button onClick={resetSeg} aria-label="やり直す" className="h-12 w-12 grid place-items-center rounded-full active:scale-90 transition" style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.85)" }}>
            <RotateCcw size={20} />
          </button>
          <button onClick={() => setRunning((r) => !r)} aria-label={running ? "一時停止" : "開始"} className="grid place-items-center rounded-full active:scale-95 transition" style={{ height: 80, width: 80, background: ring, color: "#0B0B0F", boxShadow: `0 12px 40px ${ring}55` }}>
            {running ? <Pause size={30} fill="#0B0B0F" /> : <Play size={30} fill="#0B0B0F" style={{ marginLeft: 3 }} />}
          </button>
          <button onClick={skipSeg} aria-label="スキップ" className="h-12 w-12 grid place-items-center rounded-full active:scale-90 transition" style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.85)" }}>
            <SkipForward size={20} />
          </button>
        </div>
      </div>

      {/* complete current task */}
      <div className="shrink-0 px-8 pt-3 pb-10 text-center" style={{ minHeight: 96 }}>
        {!isBreak && currentTask && (
          <>
            <button onClick={completeTask} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full active:scale-95 transition" style={{ background: "rgba(255,255,255,0.10)", color: "#fff", fontSize: 16, fontWeight: 600 }}>
              <span className="grid place-items-center rounded-full" style={{ height: 22, width: 22, border: `1.8px solid ${ring}` }}>
                <Check size={13} strokeWidth={3.4} color={ring} />
              </span>
              このタスクを完了
            </button>
            {nextTask && (
              <div className="mt-3" style={{ fontSize: 13, color: "rgba(255,255,255,0.4)" }}>次: {nextTask.text}</div>
            )}
          </>
        )}
        {isBreak && (
          <div style={{ fontSize: 14, color: "rgba(255,255,255,0.5)" }}>
            {done} 回集中したよ。少し休もう。
          </div>
        )}
      </div>
    </div>
  );
}

// ---- iOS alert -----------------------------------------------------
function Alert({ title, message, onCancel, onConfirm }) {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center px-8" style={{ background: "rgba(0,0,0,0.25)" }} onClick={onCancel}>
      <div className="w-full rounded-[14px] overflow-hidden" style={{ background: "rgba(250,250,250,0.98)", maxWidth: 270, backdropFilter: "blur(20px)" }} onClick={(e) => e.stopPropagation()}>
        <div className="px-4 pt-5 pb-4 text-center">
          <div style={{ fontSize: 17, fontWeight: 600 }}>{title}</div>
          <div className="mt-1" style={{ fontSize: 13, color: iOS.secondary }}>{message}</div>
        </div>
        <div className="flex" style={{ borderTop: `0.5px solid ${iOS.separator}` }}>
          <button onClick={onCancel} className="flex-1 py-3" style={{ fontSize: 17, color: iOS.blue, borderRight: `0.5px solid ${iOS.separator}` }}>キャンセル</button>
          <button onClick={onConfirm} className="flex-1 py-3" style={{ fontSize: 17, fontWeight: 600, color: iOS.red }}>削除</button>
        </div>
      </div>
    </div>
  );
}
